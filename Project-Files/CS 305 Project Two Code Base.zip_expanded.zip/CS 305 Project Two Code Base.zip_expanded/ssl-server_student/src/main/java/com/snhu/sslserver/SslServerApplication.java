package com.snhu.sslserver;

// Import necessary classes from the Spring framework
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

// Annotation to mark this class as a Spring Boot application
@SpringBootApplication
public class SslServerApplication {

    // Main method to start the Spring Boot application
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

}

// Annotation to indicate that this class is a REST controller
@RestController
class ChecksumController {

    // Mapping the "/checksum" URL path to this method
    @RequestMapping("/hash")
    public String myHash() {
        // The data to be hashed
        String data = "Hello Mubeen Ahmed Khan!";
        // The hashing algorithm to be used
        String algorithm = "SHA-256";
        // Generate the checksum using the specified data and algorithm
        String hash = generateChecksum(data, algorithm);
        
        // Return an HTML response containing the data, algorithm, and generated checksum
        return "<p>Data: " + data + "</p><p>Algorithm: " + algorithm + "</p><p>Checksum: " + hash + "</p>";
    }
    
    // Private method to generate a checksum of the data using the specified algorithm
    private String generateChecksum(String data, String algorithm) {
        try {
            // Get an instance of the specified MessageDigest algorithm
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            // Calculate the hash bytes of the data
            byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8)); // Added Standard Character Sets (UTF-8) for better character encoding
            // Convert the hash bytes to a hexadecimal string
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            // Handle the case where the specified algorithm is not available
            e.printStackTrace();
            return null;
        }
    }
    
    // Private method to convert an array of bytes to a hexadecimal string
    private String bytesToHex(byte[] bytes) {
        // StringBuilder to efficiently build the hexadecimal string
        StringBuilder hexString = new StringBuilder(2 * bytes.length);
        for (byte b : bytes) {
            // Convert each byte to a hexadecimal string
            String hex = Integer.toHexString(0xff & b);
            // Append a leading zero if necessary to ensure two-digit representation
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        // Return the complete hexadecimal string
        return hexString.toString();
    }
}
